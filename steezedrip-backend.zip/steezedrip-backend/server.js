require("dotenv").config();
const express = require("express");
const cors = require("cors");

const paymentRoutes = require("./routes/payment");
const webhookRoutes = require("./routes/webhook");

const app = express();

app.use(cors({ origin: process.env.FRONTEND_URL || "*" }));
app.use(express.json());

app.get("/", (req, res) => res.send("SteezeDrip backend is running."));

app.use("/api/checkout", paymentRoutes);
app.use("/api/webhook", webhookRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`SteezeDrip backend listening on port ${PORT}`));
