const express = require("express");
const { getOrder, saveOrder } = require("../utils/orderStore");
const { verifyTransaction } = require("../utils/flutterwave");

const router = express.Router();

// POST /api/webhook/flutterwave
// Flutterwave calls this on its own — mainly a safety net in case the
// customer closes their browser before the redirect fires (bank transfer
// and USSD payments especially can complete minutes later).
router.post("/flutterwave", async (req, res) => {
  const signature = req.headers["verif-hash"];

  // Flutterwave's docs describe two verification styles across API versions:
  //  1) a direct string match against the "Secret Hash" you set in your
  //     dashboard (header: verif-hash) — what's implemented below.
  //  2) an HMAC-SHA256 signature of the raw body (header: flutterwave-signature).
  // Double check Settings > Webhooks in your dashboard when you set this up —
  // if it asks for the HMAC style instead, ping me and I'll switch this over.
  if (!signature || signature !== process.env.FLW_SECRET_HASH) {
    return res.status(401).end();
  }

  // Acknowledge immediately — Flutterwave times out after 60s and will
  // retry on anything other than a fast 2xx.
  res.status(200).end();

  try {
    const payload = req.body;
    const txRef = payload && payload.data && payload.data.tx_ref;
    if (!txRef) return;

    const order = getOrder(txRef);
    if (!order || order.status === "paid") return; // unknown or already handled

    // Re-verify server-to-server rather than trusting the webhook body alone.
    const verifyResponse = await verifyTransaction(payload.data.id);
    const data = verifyResponse.data;

    const isValid =
      verifyResponse.status === "success" &&
      data.status === "successful" &&
      data.tx_ref === order.txRef &&
      Number(data.amount) >= Number(order.totalNGN);

    if (isValid) {
      order.status = "paid";
      order.flwTransactionId = payload.data.id;
      order.paidAt = new Date().toISOString();
      saveOrder(order);
      console.log(`Order ${txRef} confirmed paid via webhook.`);
    }
  } catch (err) {
    console.error("webhook processing error:", err.response ? err.response.data : err.message);
  }
});

module.exports = router;
