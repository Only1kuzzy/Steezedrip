const express = require("express");
const { v4: uuidv4 } = require("uuid");
const { initializePayment, verifyTransaction } = require("../utils/flutterwave");
const { computeTotal } = require("../utils/catalog");
const { saveOrder, getOrder } = require("../utils/orderStore");

const router = express.Router();

// POST /api/checkout/initialize
// Frontend calls this with the cart + customer details.
// We recompute the total ourselves, store a pending order, ask Flutterwave
// for a hosted checkout link, and hand that link back.
router.post("/initialize", async (req, res) => {
  try {
    const { customer, items } = req.body;

    if (!customer || !customer.email || !customer.phone || !customer.name) {
      return res.status(400).json({ error: "Customer name, email and phone are required." });
    }
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "Cart is empty." });
    }

    const { total, lineItems } = computeTotal(items);
    if (total <= 0) {
      return res.status(400).json({ error: "Could not calculate a valid order total." });
    }

    const txRef = `steezedrip-${uuidv4()}`;

    const order = {
      txRef,
      status: "pending",
      customer,
      items: lineItems,
      totalNGN: total,
      createdAt: new Date().toISOString(),
    };
    saveOrder(order);

    const redirectUrl = `${process.env.BACKEND_URL}/api/checkout/complete`;

    const flwResponse = await initializePayment({
      txRef,
      amount: total,
      currency: "NGN",
      customer: {
        email: customer.email,
        name: customer.name,
        phonenumber: customer.phone,
      },
      redirectUrl,
      title: "SteezeDrip Checkout",
    });

    if (flwResponse.status !== "success") {
      return res.status(502).json({ error: "Could not start payment. Please try again." });
    }

    res.json({ link: flwResponse.data.link, txRef });
  } catch (err) {
    console.error("initialize error:", err.response ? err.response.data : err.message);
    res.status(500).json({ error: "Something went wrong starting your payment." });
  }
});

// GET /api/checkout/complete
// Flutterwave redirects the customer's browser here after they pay (or
// cancel). We verify the transaction server-to-server before trusting
// anything, then bounce them back to the frontend with a simple status flag.
router.get("/complete", async (req, res) => {
  const { transaction_id, tx_ref, status } = req.query;
  const frontendUrl = process.env.FRONTEND_URL || "/";

  if (status === "cancelled") {
    return res.redirect(`${frontendUrl}?order=cancelled`);
  }

  try {
    const order = getOrder(tx_ref);
    if (!order) {
      return res.redirect(`${frontendUrl}?order=failed&reason=not_found`);
    }

    const verifyResponse = await verifyTransaction(transaction_id);
    const data = verifyResponse.data;

    const isValid =
      verifyResponse.status === "success" &&
      data.status === "successful" &&
      data.tx_ref === order.txRef &&
      data.currency === "NGN" &&
      Number(data.amount) >= Number(order.totalNGN);

    if (isValid) {
      order.status = "paid";
      order.flwTransactionId = transaction_id;
      order.paidAt = new Date().toISOString();
      saveOrder(order);
      return res.redirect(`${frontendUrl}?order=success&ref=${order.txRef}`);
    }

    order.status = "failed";
    saveOrder(order);
    return res.redirect(`${frontendUrl}?order=failed&ref=${order.txRef}`);
  } catch (err) {
    console.error("verify error:", err.response ? err.response.data : err.message);
    return res.redirect(`${frontendUrl}?order=failed`);
  }
});

// GET /api/checkout/order/:txRef — handy for checking an order's status
router.get("/order/:txRef", (req, res) => {
  const order = getOrder(req.params.txRef);
  if (!order) return res.status(404).json({ error: "Order not found." });
  res.json(order);
});

module.exports = router;
