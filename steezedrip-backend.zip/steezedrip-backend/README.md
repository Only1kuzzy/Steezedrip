# SteezeDrip Backend

A small Express API that sits between the SteezeDrip website and Flutterwave.
It exists so your **secret key never has to touch the browser** — the
frontend only ever talks to this backend, and this backend is the only thing
that talks to Flutterwave.

```
Frontend (SteezeDrip.jsx)  →  This backend  →  Flutterwave
        ↑__________________________|
           (redirected back after payment)
```

## What it does

- `POST /api/checkout/initialize` — takes the cart + customer info, **recalculates the total itself** from `utils/catalog.js` (never trusts a price sent from the browser), creates a pending order, and asks Flutterwave for a hosted payment link.
- `GET /api/checkout/complete` — Flutterwave sends the customer's browser here after they pay. We verify the transaction with Flutterwave directly (not just trusting the redirect), mark the order paid or failed, then bounce them back to your site with `?order=success` or `?order=failed`.
- `POST /api/webhook/flutterwave` — a safety net for payments that settle later (bank transfer, USSD), and for cases where the customer closes the tab before the redirect happens.
- Orders are saved to `data/orders.json`. That's fine to start with, but move to a real database (Postgres, MongoDB, etc.) before you're relying on this for real volume — a JSON file has no protection against two orders writing at once.

## 1. Create your Flutterwave account

You said you don't have one yet — here's the quick path:

1. Go to [flutterwave.com](https://flutterwave.com) and sign up for a business account.
2. Verify your email. You'll land in your dashboard in **Test Mode** — you can get test API keys immediately, before your business KYC is approved, so you can build and test everything now.
3. In the dashboard sidebar: **Settings → API** — copy your **Public Key** and **Secret Key** (they'll be prefixed `FLWPUBK_TEST-` / `FLWSECK_TEST-` while in test mode).
4. In **Settings → Webhooks** — enter a webhook URL (you'll add the real one once deployed, see below) and set a **Secret Hash** (make up any long random string — you'll paste this same value into `.env`).
5. When you're ready to accept real money: complete the KYC/business verification Flutterwave asks for, then switch the dashboard to **Live Mode** to get your live keys.

## 2. Local setup

```bash
cd steezedrip-backend
npm install
cp .env.example .env
```

Open `.env` and fill in:
- `FLW_PUBLIC_KEY` / `FLW_SECRET_KEY` — from step 1
- `FLW_SECRET_HASH` — the same random string you put in the dashboard
- `FRONTEND_URL` — wherever your SteezeDrip site is hosted
- `BACKEND_URL` — leave as `http://localhost:4000` for now if testing locally

Run it:

```bash
npm run dev
```

You should see `SteezeDrip backend listening on port 4000`.

### Testing webhooks locally

Flutterwave needs a public HTTPS URL to send webhooks to — it can't reach `localhost`. For local testing, use [ngrok](https://ngrok.com):

```bash
ngrok http 4000
```

Take the `https://...ngrok-free.app` URL it gives you and put `<that-url>/api/webhook/flutterwave` into your Flutterwave dashboard's webhook settings.

## 3. Deploy it somewhere

Any Node host works. **Render** or **Railway** are the easiest free options:

1. Push this folder to a GitHub repo.
2. On Render/Railway: **New → Web Service**, connect the repo.
3. Build command: `npm install`. Start command: `npm start`.
4. Add all the variables from `.env` in the host's "Environment Variables" section — **don't commit your real `.env` file to GitHub.**
5. Deploy. Copy the live URL it gives you (e.g. `https://steezedrip-backend.onrender.com`).
6. Update `BACKEND_URL` in your environment variables to that exact URL, and redeploy.
7. Back in the Flutterwave dashboard, update your webhook URL to `https://your-backend-url/api/webhook/flutterwave`.

## 4. Connect the frontend

In `SteezeDrip.jsx`, near the top, set:

```js
const BACKEND_URL = "https://steezedrip-backend.onrender.com"; // your deployed URL
```

That's it — the "Pay With Card" option in checkout will call this backend, which creates the Flutterwave payment link and redirects the customer to it.

## 5. Going live

- Switch your Flutterwave dashboard to **Live Mode**.
- Replace the `FLW_PUBLIC_KEY` / `FLW_SECRET_KEY` env vars on your host with the **live** keys (no `_TEST` in them).
- Live mode has its own webhook secret hash — set it separately in the dashboard and update `FLW_SECRET_HASH`.
- Do one small real transaction yourself before opening it up to customers.

## Security notes

- The secret key (`FLW_SECRET_KEY`) only ever lives in this backend's environment variables — never in the frontend, never in git.
- Prices are only ever trusted from `utils/catalog.js` on this server, never from the browser.
- Every payment is verified twice: once right after redirect, and again independently via the webhook, so a flaky connection on the customer's end doesn't lose you an order.
