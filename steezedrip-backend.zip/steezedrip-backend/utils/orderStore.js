// Minimal file-based order storage — good enough to get started.
//
// Before this shop gets real volume, swap this out for a proper database
// (Postgres, MongoDB, etc.) — a JSON file has no protection against two
// requests writing at the same time.

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "data", "orders.json");

function readAll() {
  try {
    const raw = fs.readFileSync(DB_PATH, "utf-8");
    return JSON.parse(raw || "{}");
  } catch (err) {
    return {};
  }
}

function writeAll(orders) {
  fs.writeFileSync(DB_PATH, JSON.stringify(orders, null, 2));
}

function saveOrder(order) {
  const orders = readAll();
  orders[order.txRef] = order;
  writeAll(orders);
  return order;
}

function getOrder(txRef) {
  const orders = readAll();
  return orders[txRef] || null;
}

module.exports = { saveOrder, getOrder, readAll };
