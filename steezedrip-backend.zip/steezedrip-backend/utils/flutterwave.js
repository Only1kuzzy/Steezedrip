const axios = require("axios");

const FLW_BASE_URL = "https://api.flutterwave.com/v3";

function flwHeaders() {
  return {
    Authorization: `Bearer ${process.env.FLW_SECRET_KEY}`,
    "Content-Type": "application/json",
  };
}

// Creates a hosted payment link (Flutterwave "Standard" checkout flow).
// Docs: https://developer.flutterwave.com/v3.0/docs/flutterwave-standard-1
async function initializePayment({ txRef, amount, currency, customer, redirectUrl, title }) {
  const response = await axios.post(
    `${FLW_BASE_URL}/payments`,
    {
      tx_ref: txRef,
      amount,
      currency,
      redirect_url: redirectUrl,
      customer,
      customizations: { title },
    },
    { headers: flwHeaders() }
  );
  return response.data; // { status, message, data: { link } }
}

// Confirms a transaction's real status server-to-server. Never trust the
// query params on the redirect alone — always verify like this first.
async function verifyTransaction(transactionId) {
  const response = await axios.get(
    `${FLW_BASE_URL}/transactions/${transactionId}/verify`,
    { headers: flwHeaders() }
  );
  return response.data; // { status, message, data: {...} }
}

module.exports = { initializePayment, verifyTransaction };
