// Server-side source of truth for prices.
//
// IMPORTANT: never trust a price or total sent from the browser — a visitor
// can edit that with their dev tools. The backend always recomputes the
// order total itself from this catalog before creating a payment.
//
// Keep this in sync with the `COLLECTION` array in the frontend (SteezeDrip.jsx).

const PRODUCTS = {
  "not-average-tee": { name: "Not Average Tee", priceNGN: 45000 },
  "steeze-tee": { name: "Steeze. Tee", priceNGN: 52000 },
  "steeze-varsity-09": { name: "Steeze Varsity 09", priceNGN: 68000 },
};

function computeTotal(items) {
  let total = 0;
  const lineItems = [];

  for (const item of items || []) {
    const product = PRODUCTS[item.id];
    if (!product) continue; // unknown product id — ignore rather than trust it

    const qty = Math.max(1, parseInt(item.qty, 10) || 1);
    const lineTotal = product.priceNGN * qty;
    total += lineTotal;

    lineItems.push({
      id: item.id,
      name: product.name,
      size: item.size || "-",
      color: item.color || "-",
      qty,
      unitPriceNGN: product.priceNGN,
      lineTotalNGN: lineTotal,
    });
  }

  return { total, lineItems };
}

module.exports = { PRODUCTS, computeTotal };
